import React from 'react'

export const About = () => {
  return (
    <div>This is About</div>
  )
}

export default About
